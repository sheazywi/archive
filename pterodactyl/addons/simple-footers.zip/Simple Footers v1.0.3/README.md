Disclaimer: This extension requires blueprint to run! Learn more at "ptero.shop"

Current targeted version of blueprint: alpha-IPS
Installing any version of blueprint above alpha-IPS will be compatible with this version of the extension

1. Drag "simplefooters.blueprint" into your Pterodactyl folder (your Pterodactyl directory will typically be in /var/www/pterodactyl).
2. Run this command: "blueprint -i simplefooters" (Make sure you run this command in your Pterodactyl directory)
3. Your installation should be finished!

If you need support please DM me on Discord: pyuwu17 or email me at: patrick@patrickyu.me

Thank you for installing this extension!
Feel free to check my other extensions!

